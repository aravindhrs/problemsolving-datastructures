package com.problemsolving;

public class MergeLL {

	public static void main(String[] args) {

		Node six = new Node(null, 6);
		Node four = new Node(six, 4);
		Node three = new Node(four, 3);
		Node one = new Node(three, 1); // head of first list

		Node seven = new Node(null, 7);
		Node five = new Node(seven, 5);
		Node two = new Node(five, 2); // head of second list

		Node head = mergeTwoLists(one, two);

		Node curr = head;
		while (curr != null) {
			System.out.println(curr.data);
			curr = curr.next;
		}

	}

	public static Node mergeTwoLists(Node p1, Node p2) {
		Node head = new Node(null, 0);
		Node p = head;
		while (p1 != null && p2 != null) {
			if (p1.data < p2.data) {
				p.next = p1;
				p1 = p1.next;
			} else {
				p.next = p2;
				p2 = p2.next;
			}
			p = p.next;
		}

		if (p1 != null) {
			p.next = p1;
		}

		if (p2 != null) {
			p.next = p2;
		}

		return head.next;
	}
}

class Node {
	Node next;
	int data;

	Node(Node next, int data) {
		this.data = data;
		this.next = next;
	}
}
