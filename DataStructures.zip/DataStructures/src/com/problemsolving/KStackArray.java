package com.problemsolving;

import java.util.Arrays;

public class KStackArray {

	static class KStack{
		int arr[];
		int top[];
		int next[];
		
		int n, k, free;
		
		public KStack(int k1, int n1) {
			k=k1;
			n=n1;
			this.arr=new int[n];
			this.next=new int[n];
			this.top=new int[k];
			
			for(int i=0;i<k;i++){
				this.top[i]=-1;
			}
			
			free=0;
			
			for(int i=0;i<n-1;i++){
				next[i]=i+1;
			}
			
			next[n-1]=-1;
			
			System.out.println("Next:"+Arrays.toString(next));
			System.out.println("top:"+Arrays.toString(top));
			System.out.println("arr:"+Arrays.toString(arr));
			System.out.println("-------------------------------------");
		}
		
		void push(int item, int sn){
			if(isStackFull()){
				System.out.println("Stack Overflow error!!!");
				return;
			}
			
			int index = free;
			System.out.print("index:"+free);
			free = next[index];
			System.out.print(" free:"+next[index]);
			next[index]=top[sn];
			System.out.print(" next["+index+"]:"+next[index]);
			top[sn]=index;
			System.out.print(" top["+sn+"]:"+top[sn]);
			arr[index]=item;
			System.out.print(" arr["+index+"]:"+arr[index]);
			System.out.println("\n-------------------------------------");
		}
		
		int pop(int sn){
			if(isStackEmpty(sn)){
				System.out.println("Stack underflow error!!!");
				return Integer.MAX_VALUE;
			}
			return 0;
		}
		
		boolean isStackFull(){
			return (free==-1);
		}
		
		boolean isStackEmpty(int sn){
			return (top[sn]==-1);
		}
	}
	
	public static void main(String[] args) {
		int k=3, n=10;
		
		KStack stack = new KStack(k, n);
		stack.push(21, 0);
		stack.push(12, 1);
		//stack.push(43, 2);
		stack.push(71, 0);
		//stack.push(73, 0);
	}
}