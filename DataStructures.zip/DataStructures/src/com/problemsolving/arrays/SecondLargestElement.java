package com.problemsolving.arrays;

import static java.lang.Integer.*;

public class SecondLargestElement {

	static int secondLargest(int[] input) {
		int firstLargest=MIN_VALUE,secondLargest=MIN_VALUE;
		for (int i = 0; i < input.length; i++) {
			if (input[i] > firstLargest) {
				secondLargest = firstLargest;
				firstLargest = input[i];
			} else if (input[i] < firstLargest && input[i] > secondLargest) {
				secondLargest = input[i];
			}
		}
		return secondLargest;
	}

	public static void main(String[] args) {
		System.out.println(secondLargest(new int[] { 1, 5 }));
	}
}
