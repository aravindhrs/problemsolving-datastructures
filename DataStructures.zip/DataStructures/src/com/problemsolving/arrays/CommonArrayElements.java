package com.problemsolving.arrays;

public class CommonArrayElements {

	public static void commonElement(int arr1[],int arr2[],int arr3[]){
		int i=0,j=0,k=0;
		
		while(i<arr1.length && j<arr2.length && k<arr3.length){
			//if(arr1[i])
		}
	}
	
	public static void main(String[] args) {
		int arr1[] = {20,15,65,78,95};
		int arr2[] = {14,51,20,15,65,89,46};
		int arr3[] = {20,45,87,65};
		
		commonElement(arr1, arr2, arr3);
	}
}
