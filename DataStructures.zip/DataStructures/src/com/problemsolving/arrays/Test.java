package com.problemsolving.arrays;

public class Test {

	public static void main(String[] args) {
		System.out.println(3 | 5);
	}

}
