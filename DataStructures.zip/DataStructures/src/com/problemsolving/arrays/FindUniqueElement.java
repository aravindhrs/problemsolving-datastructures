package com.problemsolving.arrays;

public class FindUniqueElement {

	static final int INT_SIZE = 32;

	static int getSingle(int arr[], int n) {
		int result = 0;
		int x, sum;

		for (int i = 0; i < INT_SIZE; i++) {
			sum = 0;
			x = (1 << i);
			System.out.println("X:"+x);
			for (int j = 0; j < n; j++) {
				if ((arr[j] & x) == 0){
					sum++;
					System.out.print("Sum:"+sum+" ");
				}
			}
			System.out.println();
			if ((sum % 3) == 0){
				result |= x;
				System.out.println("Result:"+result+" X:"+x);
			}
		}
		return result;
	}

	public static void main(String[] args) {
		int arr[] = {42, 1, 42, 3, 42, 1, 1, 2, 3, 2, 2, 3, 7};
        int n = arr.length;
        System.out.println("The element with single occurrence is " + getSingle(arr, n));
	}
}
