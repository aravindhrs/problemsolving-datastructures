package com.problemsolving.arrays;

public class ThreeWayPartitioning {
	// Linear-time partition routine to sort an array containing 0, 1 and 2
	// It similar to three-way Partitioning for Dutch national flag problem
	public static void threeWayPartition(int A[], int end)
	{
		int start = 0, mid = 0;
		int pivot = 1;
		int temp;
	 
		while (mid <= end)
		{
			if (A[mid] < pivot)			// current element is 0
			{
				// swap(A[start], A[mid])

				temp = A[start];
				A[start] = A[mid];
				A[mid] = temp;

				++start;
				++mid;
			}
			else if (A[mid] > pivot)	// current element is 2
			{
				// swap (A[mid], A[end])

				temp = A[mid];
				A[mid] = A[end];
				A[end] = temp;

				--end;
			}
			else						// current element is 1
				++mid;
		}
	}

	// main function
	public static void main (String[] args)
	{
		int A[] = { 0, 1, 2, 2, 1, 0, 0, 2, 0, 1, 1, 0 };
		int n = A.length;

		threeWayPartition(A, n - 1);

		for (int i = 0 ; i < n; i++)
			System.out.print(A[i] + " ");
	}
}