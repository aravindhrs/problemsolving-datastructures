package com.problemsolving.arrays;

import java.util.Arrays;

//Two pointers
public class ReverseStringInPlace {

	public static void reverseInPlaceUsingWhileloop(String[] strArray) {
		if (strArray.length < 2) {
			return;
		} else {
			int i = 0;
			int j = strArray.length - 1;
			while (i < j) {
				String temp = strArray[i];
				strArray[i] = strArray[j];
				strArray[j] = temp;
				i++;
				j--;
			}
		}
	}

	public static void reverseString(String[] array) {
		if (array.length < 2) {
			return;
		} else {
			for (int i = 0; i < array.length / 2; i++) {
				String temp = array[i];
				array[i] = array[array.length - 1 - i];
				array[array.length - 1 - i] = temp;
			}
		}
	}

	public static void swapLessElements(String[] array) {
		String temp = array[0];
		array[0] = array[1];
		array[1] = temp;
	}

	public static void main(String[] args) {

		String[] inputArray = { "ranjeet", "kumar", "jha" };
		System.out.println("original string array: " + Arrays.toString(inputArray));
		reverseString(inputArray);
		System.out.println("reversed string array: " + Arrays.toString(inputArray));

		System.out.println("===========================");

		String[] languages = { "java", "spring", "c++" };
		System.out.println("Before reversed languages: " + Arrays.toString(languages));
		reverseInPlaceUsingWhileloop(languages);
		System.out.println("after reversed languages: " + Arrays.toString(languages));
	}
}
