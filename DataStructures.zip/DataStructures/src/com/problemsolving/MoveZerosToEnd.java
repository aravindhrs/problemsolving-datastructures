package com.problemsolving;

//Time complexity - O(n)
public class MoveZerosToEnd {

	public static void moveZeroes(int[] nums) {
		int m = -1;
		//2, 0, 1, 3, 0, 5
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == 0) {
				if (m == -1 || nums[m] != 0) {
					m = i;
				}
			} else {
				if (m != -1) {
					int temp = nums[i];
					nums[i] = nums[m];
					nums[m] = temp;
					m++;
				}
			}
		}
	}

	public static void main(String[] args) {
		int[] arr = { 2, 0, 1, 3, 0, 5 };
		moveZeroes(arr);
		for (int element : arr)
			System.out.print(element + " ");
	}
}
