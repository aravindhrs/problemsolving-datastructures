package com.problemsolving;

import java.util.Date;

class OverLoad{
	
	public OverLoad(){
		System.out.println("Constructor");
	}
	
	public void method1(Object str){
		System.out.println("Inside Object method:"+str);
	}
	
	public void method1(Integer str){
		System.out.println("Inside Integer method:"+str);
	}
	
	public void method1(String str){
		System.out.println("Inside String method:"+str);
	}
	
}

public class OverLoadingTest {

	public static void main(String[] args) {
		OverLoad overLoad = new OverLoad();
		overLoad.method1("Hello");
		overLoad.method1(126);
		overLoad.method1(new Date(12000));
		overLoad.method1((String)null);
	}
}
