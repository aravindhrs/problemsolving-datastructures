package com.problemsolving;

public class StringToNumber {

	public static int convertStringToNumber(String str) {
		char ch[] = str.toCharArray();
		int sum = 0;
		int zeroAscii = (int) '0';

		for (char c : ch) {
			int tmpAscii = (int) c;
			sum = (sum * 10) + (tmpAscii - zeroAscii);
		}
		return sum;
	}

	public static void main(String[] args) {
		System.out.println("\"3256\" == " + convertStringToNumber("3256"));
		System.out.println("\"76289\" == " + convertStringToNumber("76289"));
		System.out.println("\"90087\" == " + convertStringToNumber("90087"));
	}
}
