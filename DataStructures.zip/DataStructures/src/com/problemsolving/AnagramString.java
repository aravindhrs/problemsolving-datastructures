package com.problemsolving;

import java.util.Arrays;

public class AnagramString {
	public static boolean isAnagramUsingSB(String first, String second) {
		char[] characters = first.toCharArray();
		StringBuilder sbSecond = new StringBuilder(second);
		for (char ch : characters) {
			int index = sbSecond.indexOf("" + ch);
			if (index != -1) {
				sbSecond.deleteCharAt(index);
			} else {
				return false;
			}
		}
		return sbSecond.length() == 0 ? true : false;
	}

	public static boolean isAnagramByUsingArrays(String str1, String str2) {
		char[] charFromStr1 = str1.toCharArray();
		char[] charFromStr2 = str2.toCharArray();
		Arrays.sort(charFromStr1);
		Arrays.sort(charFromStr2);
		return Arrays.equals(charFromStr1, charFromStr2);
	}

	public static void main(String[] args) {
		System.out.println(isAnagramByUsingArrays("cab", "abc"));
		System.out.println(isAnagramUsingSB("word", "wdro"));
	}
}
