package com.problemsolving;

import java.util.ArrayList;
import java.util.List;

public class DuplicateNumbers {

	public int findDuplicate(List<Integer> list){
		int highestNumber = list.size()-1;
		int sum = getSum(list);
		int duplicate = sum - (highestNumber*(highestNumber+1)/2);
		return duplicate;
	}
	
	public int getSum(List<Integer> list){
		int sum=0;
		for(int num:list){
			sum += num;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		for(int i=20;i<30;i++){
			list.add(i);
        }
		list.add(25);
		
		DuplicateNumbers duplicateNumbers = new DuplicateNumbers();
		System.out.println(duplicateNumbers.findDuplicate(list));
	}
}
