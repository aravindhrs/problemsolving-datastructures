package com.problemsolving;

import java.util.Arrays;

public class MaxConsecutiveSum {

	static void rearrange(int arr[]) {
		Arrays.sort(arr);
		System.out.println("After Dual-Pivot Quicksort : " + Arrays.toString(arr));
		
		int length = arr.length;
		int max_idx = length - 1, min_idx = 0;
		int max_elem = arr[length - 1] + 1;

		for (int i = 0; i < length; i++) {
			if (i % 2 == 0) {
				arr[i] += (arr[min_idx] % max_elem) * max_elem;
				System.out.println(Arrays.toString(arr));
				min_idx++;
			} else {
				arr[i] += (arr[max_idx] % max_elem) * max_elem;
				max_idx--;
			}
		}

		for (int i = 0; i < length; i++)
			arr[i] = arr[i] / max_elem;

		System.out.println("After Rearrange: " + Arrays.toString(arr));
	}

	static int sum(int arr[]) {
		rearrange(arr);
		int sum = 0;

		for (int i = 0; i < arr.length - 1; i++) {
			sum = sum + Math.abs(arr[i] - arr[i + 1]);
		}

		sum = sum + Math.abs(arr[arr.length - 1] - arr[0]);
		return sum;
	}

	public static void main(String[] args) {
		/*int arr[] = { 4, 2, 1, 8 };
		System.out.println("Sum is:" + sum(arr));
		System.out.println();
		int arr1[] = { 2, 3, 6, 5, 4, 1, 7 };
		System.out.println("Sum is:" + sum(arr1));
		System.out.println();*/
		int arr2[] = { 2, 3, 5, 4, 1 };
		System.out.println("Sum is:" + sum(arr2));
	}
}
