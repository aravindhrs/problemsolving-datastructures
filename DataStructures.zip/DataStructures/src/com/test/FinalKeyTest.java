package com.test;

class Foo{
	
}

public class FinalKeyTest extends Foo{

	public static void main(String[] args) {
		new FinalKeyTest();
	}
}
