package com.concurrency;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;

class ExchangerThread extends Thread {
	Exchanger<String> exchanger;
	String message;
	String name;
	CyclicBarrier barrier;

	public ExchangerThread(Exchanger<String> exchanger, String message, String name,CyclicBarrier barrier) {
		this.exchanger = exchanger;
		this.message = message;
		this.name=name;
		this.barrier=barrier;
	}

	@Override
	public void run() {
		System.out.println(this.name + " message: " + message);
		try {
			barrier.await();
			System.out.println("------------------");
			message = exchanger.exchange(message);
			System.out.println(this.name + " message: " + message);
		} catch (InterruptedException | BrokenBarrierException e) {
			e.printStackTrace();
		}
	}
}

public class ExchangerExample {

	public static void main(String[] args) {
		Exchanger<String> exchanger = new Exchanger<>();
		CyclicBarrier cyclicBarrier = new CyclicBarrier(2);
		Thread thread1 = new Thread(new ExchangerThread(exchanger, "Hi","T1", cyclicBarrier));
		Thread thread2 = new ExchangerThread(exchanger, "HI","T2",cyclicBarrier);
		
		thread1.start();
		thread2.start();
	}
}
