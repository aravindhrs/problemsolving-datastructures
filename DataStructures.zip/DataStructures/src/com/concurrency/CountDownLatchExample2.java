package com.concurrency;

import java.util.concurrent.CountDownLatch;

class MyThread extends Thread {

	private final String name;
	private final CountDownLatch latch;

	public MyThread(String name, CountDownLatch latch) {
		this.name = name;
		this.latch = latch;
	}

	public void run() {
		System.out.println(name + " starting");
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(name + " ready");
		latch.countDown();
	}
}

public class CountDownLatchExample2 {

	public static void main(String args[]) {
		final CountDownLatch latch = new CountDownLatch(3);

		Thread T1 = new Thread(new MyThread("T1", latch));
		Thread T2 = new Thread(new MyThread("T2", latch));
		Thread T3 = new Thread(new MyThread("T3", latch));

		T1.start();
		T2.start();
		T3.start();

		try {
			latch.await();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}

		System.out.println("All threads are ready");
	}
}
