package com.concurrency;

import java.util.concurrent.Exchanger;

class RunnableThread implements Runnable{
	
	Exchanger<Object> exchanger;
	Object object;
	
	public RunnableThread(Exchanger<Object> exchanger,Object object) {
		this.exchanger=exchanger;
		this.object=object;
	}
	
	@Override
	public void run() {
		try{
			Object previous=this.object;
			this.object=this.exchanger.exchange(this.object);
			System.out.println(Thread.currentThread().getName() + " exchanged " + previous + " for " + this.object);
		}catch(InterruptedException exception){
			exception.printStackTrace();
		}
	}
}

public class ExchangerTest {

	public static void main(String[] args) {
		
		Exchanger<Object> exchanger = new Exchanger<>();
		
		RunnableThread exchangerRunnable1 = new RunnableThread(exchanger, "A");
		RunnableThread exchangerRunnable2 = new RunnableThread(exchanger, "B");
		
		new Thread(exchangerRunnable1).start();
		new Thread(exchangerRunnable2).start();
	}
}
