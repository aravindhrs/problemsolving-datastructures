package com.concurrency;

import java.util.concurrent.CountDownLatch;

class Thread1 implements Runnable{
	
	String name;
	String taskName;
	CountDownLatch countDownLatch;
	
	Thread1(String name,String taskName,CountDownLatch countDownLatch){
		this.name=name;
		this.taskName=taskName;
		this.countDownLatch=countDownLatch;
	}

	@Override
	public void run() {
		System.out.println(name+" doing the "+taskName);
		countDownLatch.countDown();
	}
}

public class CountDownLatchExample {

	public static void main(String[] args) {
		CountDownLatch countDownLatch = new CountDownLatch(3);
		Thread thread1 = new Thread(new Thread1("Thread1", "Reading", countDownLatch));
		Thread thread2 = new Thread(new Thread1("Thread2", "Processing", countDownLatch));
		Thread thread3 = new Thread(new Thread1("Thread3", "Prints", countDownLatch));
		
		thread1.start();
		thread2.start();
		thread3.start();
		
		/*List<Service> listService = new ArrayList<>();
		listService.add((Service) thread1);
		listService.add((Service) thread2);
		listService.add((Service) thread3);
		
		ExecutorService executorService = Executors.newFixedThreadPool(3);

		for(final Service service: listService){
			executorService.equals(service);
		}*/
		
		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Files are read ... Start further processing");
	}
}
