package com.concurrency;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

class CallableOne implements Callable<String> {

	@Override
	public String call() throws Exception {
		String message = "Callable 1 running...";
		System.out.println("Simple task 1 is running on " + Thread.currentThread().getName() + " with priority " + Thread.currentThread().getPriority());
		return message;
	}
}

class CallableTwo implements Callable<String> {

	@Override
	public String call() throws Exception {
		String message = "Callable 2 running...";
		System.out.println("Simple task 2 is running on " + Thread.currentThread().getName() + " with priority " + Thread.currentThread().getPriority());
		return message;
	}
}

class CallableThree implements Callable<String> {

	@Override
	public String call() throws Exception {
		String message = "Callable 3 running...";
		System.out.println("Simple task 3 is running on " + Thread.currentThread().getName() + " with priority " + Thread.currentThread().getPriority());
		return message;
	}
}

class CustomThreadFactoryBuilder {
	private String namePrefix = null;
	private boolean daemon = false;
	private int priority = Thread.NORM_PRIORITY;

	public CustomThreadFactoryBuilder setNamePrefix(String namePrefix) {
		if (namePrefix == null) {
			throw new NullPointerException();
		}
		this.namePrefix = namePrefix;
		return this;
	}

	public CustomThreadFactoryBuilder setDaemon(boolean daemon) {
		this.daemon = daemon;
		return this;
	}

	public CustomThreadFactoryBuilder setPriority(int priority) {
		if (priority < Thread.MIN_PRIORITY) {

		}

		if (priority > Thread.MAX_PRIORITY) {
			throw new IllegalArgumentException(String.format(
					"Thread priority (%s) must be <= %s", priority,
					Thread.MAX_PRIORITY));
		}

		this.priority = priority;
		return this;
	}

	public ThreadFactory build() {
		return build(this);
	}

	private static ThreadFactory build(CustomThreadFactoryBuilder builder) {
		final String namePrefix = builder.namePrefix;
		final Boolean daemon = builder.daemon;
		final Integer priority = builder.priority;

		final AtomicLong count = new AtomicLong(0);

		return new ThreadFactory() {
			@Override
			public Thread newThread(Runnable runnable) {
				Thread thread = new Thread(runnable);
				if (namePrefix != null) {
					thread.setName(namePrefix + "-" + count.getAndIncrement());
				}
				if (daemon != null) {
					thread.setDaemon(daemon);
				}
				if (priority != null) {
					thread.setPriority(priority);
				}
				return thread;
			}
		};
	}
}

public class CallableTest {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		ThreadFactory customThreadfactory = new CustomThreadFactoryBuilder()
													.setNamePrefix("DemoPool-Thread").setDaemon(false)
													.setPriority(Thread.MAX_PRIORITY).build();
		
		ExecutorService executorService = Executors.newFixedThreadPool(3,customThreadfactory);
		
		Set<Callable<String>> callableSet = new HashSet<>();
		callableSet.add(new CallableThree());
		callableSet.add(new CallableTwo());
		callableSet.add(new CallableOne());
		
		List<Future<String>> futuresList = executorService.invokeAll(callableSet);
		
		for(Future<String> futures: futuresList){
			System.out.println(futures.get());
		}
		
		String futuresListAny = executorService.invokeAny(callableSet);
		System.out.println("invokeAny Callable:"+futuresListAny);
		
		executorService.shutdown();
		executorService.awaitTermination(2000, TimeUnit.MILLISECONDS);
	}
}
