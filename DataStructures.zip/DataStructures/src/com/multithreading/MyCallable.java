package com.multithreading;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MyCallable implements Callable<Object>{

	@Override
	public String call() throws Exception {
		Thread.sleep(1000);
		return Thread.currentThread().getName();
	}
	
	public static void main(String[] args) {
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		List<Future<Object>> futuresList = new ArrayList<>();
		Callable<Object> callable = new MyCallable();
		for(int i=0;i<20;i++){
			Future<Object> future = executorService.submit(callable);
			futuresList.add(future);
		}
		
		for(Future<Object> future: futuresList){
			try {
				System.out.println(new Date()+" "+future.get());
			} catch (InterruptedException | ExecutionException e) {
				System.out.println(e.getCause());
				e.printStackTrace();
			}
		}
		executorService.shutdown();
	}
}
