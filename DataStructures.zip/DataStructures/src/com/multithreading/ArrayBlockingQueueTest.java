package com.multithreading;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

class ProducerWorker implements Runnable{
	private BlockingQueue<Integer> blockingQueue;
	String name;
	
	public ProducerWorker(BlockingQueue<Integer> blockingQueue, String name) {
		this.blockingQueue=blockingQueue;
		this.name=name;
	}

	@Override
	public void run() {
		for(int i=0;i<0;i++){
			try {
				System.out.println(Thread.currentThread().getName()+" puts "+i);
				blockingQueue.put(i);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

class ConsumerWorker implements Runnable{

	private BlockingQueue<Integer> blockingQueue;
	String name;
	
	public ConsumerWorker(BlockingQueue<Integer> blockingQueue, String name) {
		this.blockingQueue=blockingQueue;
		this.name=name;
	}
	
	@Override
	public void run() {
		while(true){
			try {
				System.out.println(Thread.currentThread().getName()+" takes "+blockingQueue.take());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

public class ArrayBlockingQueueTest {

	public static void main(String[] args) throws InterruptedException {
		BlockingQueue<Integer> blockingQueue = new ArrayBlockingQueue<>(5);
		Thread producerWorker = new Thread(new ProducerWorker(blockingQueue, "Producer"));
		Thread consumerWorker = new Thread(new ProducerWorker(blockingQueue, "Consumer"));
		producerWorker.start();
		consumerWorker.start();
		
		BlockingQueue<String> blockingQueue2 = new LinkedBlockingQueue<>(5);
		blockingQueue2.take();
	}
}
