package com.multithreading;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class ExceptionHandlerService implements UncaughtExceptionHandler{

	@Override
	public void uncaughtException(Thread t, Throwable e) {
		
	}
	
}

class WorkerThread extends Thread{
	public void run(){
		 System.out.println(this.getName() + " started: " + new Date() );
         try {
        	Thread.currentThread().setUncaughtExceptionHandler(new ExceptionHandlerService());
			Thread.sleep(5000);
			//System.out.println(10/0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
         System.out.println(this.getName() + " finished:" + new Date() );
	}
}

public class ExecutorServiceTest {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		
		//for(int i=0;i<5;i++){
			WorkerThread workerThread = new WorkerThread();
			Future future = executorService.submit(workerThread);
			/*executorService.execute(workerThread);*/
		//}
		System.out.println((String)future.get());
		executorService.shutdown();
	}
	
	/*public class IntegerComparator implements Comparator<Integer> {

	    @Override
	    public int compare(Integer o1, Integer o2) {
	        return o2.compareTo(o1);
	    }
	}*/
}
