package com.multithreading;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

class Task1 implements Runnable{

	@Override
	public void run() {
		try {
			TimeUnit.MILLISECONDS.sleep(2000);
			System.out.println("Thread is executing the task...");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

class CustomThreadFactory implements ThreadFactory{
	private String name;
	private List<String> stats;
	AtomicInteger atomicInteger;
	
	public CustomThreadFactory(String name){
		atomicInteger = new AtomicInteger(0);
		this.name=name;
		stats=new ArrayList<>();
	}

	@Override
	public Thread newThread(Runnable runnable) {
		Thread thread = new Thread(runnable, name+"_Thread_"+atomicInteger.getAndDecrement());
		stats.add(String.format("Created thread %d with name %s on %s \n", thread.getId(), thread.getName(), new Date()));
		return thread;
	}
	
	public String getStats(){
		StringBuffer buffer = new StringBuffer();
		Iterator<String> iterator = stats.iterator();
		while (iterator.hasNext()) {
			buffer.append(iterator.next());
		}
		return buffer.toString();
	}
}

public class CustomThreadFactoryTest {
	public static void main(String[] args) {
		CustomThreadFactory customThreadFactory = new CustomThreadFactory("CustomThreadFactory");
		Task1 task1 = new Task1();
		Thread thread;
		System.out.printf("Starting the Threads\n\n");
		
		AtomicInteger integer=new AtomicInteger(0);
		while(integer.getAndIncrement()<10){
			thread = customThreadFactory.newThread(task1);
			thread.start();
		}
		
		System.out.printf("All Threads are created now\n\n");
		System.out.printf("Give me CustomThreadFactory stats:\n\n" + customThreadFactory.getStats());
	}
}
