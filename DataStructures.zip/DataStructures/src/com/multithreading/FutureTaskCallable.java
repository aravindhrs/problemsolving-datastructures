package com.multithreading;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class MyCallables implements Callable<String> {

	private long waitTime;

	public MyCallables(int timeInMillis) {
		this.waitTime = timeInMillis;
	}

	@Override
	public String call() throws Exception {
		Thread.sleep(waitTime);
		return Thread.currentThread().getName();
	}
}

public class FutureTaskCallable {
	public static void main(String[] args) throws InterruptedException {
		MyCallables callable1 = new MyCallables(1000);
		MyCallables callable2 = new MyCallables(2000);

		FutureTask<String> futureTask1 = new FutureTask<String>(callable1);
		FutureTask<String> futureTask2 = new FutureTask<String>(callable2);

		ExecutorService executor = Executors.newFixedThreadPool(2);
		executor.execute(futureTask1);
		executor.execute(futureTask2);
		
		CompletionService<String> compService = new ExecutorCompletionService<String>(Executors.newFixedThreadPool(5));
		compService.take();
		
		Executor executor1 = Executors.newFixedThreadPool(4);
		CompletionService<String> completionService = new ExecutorCompletionService<String>(executor1);
		completionService.take();
		//completionService.submit(futureTask1);
		
		while (true) {
			try {
				if (futureTask1.isDone() && futureTask2.isDone()) {
					System.out.println("Done");
					executor.shutdown();
					return;
				}

				if (!futureTask1.isDone()) {
					System.out.println("FutureTask1 output="+ futureTask1.get());
				}

				System.out.println("Waiting for FutureTask2 to complete");
				String s = futureTask2.get(200L, TimeUnit.MILLISECONDS);
				if (s != null) {
					System.out.println("FutureTask2 output=" + s);
				}
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			} catch (TimeoutException e) {
			}
		}
	}
}