package com.sorting;

public class QuickSort {

}
