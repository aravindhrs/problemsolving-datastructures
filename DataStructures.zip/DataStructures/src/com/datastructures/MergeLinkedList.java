/*package com.datastructures;

class Node {
	int data;
	Node next;

	public Node(int data) {
		this.data = data;
	}
}

class LinkedListt {
	Node head;
	class Node {
		int data;
		Node next;

		public Node(int data) {
			this.data = data;
		}
	}

	public void addToFront(int data) {
		Node n = new Node(data);
		n.next = head;
		head = n;
	}

	public void printList() {
		Node tmp = head;
		while (tmp != null) {
			System.out.print(tmp.data + " ");
			tmp = tmp.next;
		}
		System.out.println();
	}
}

public class MergeLinkedList {
	
	public static Node mergeTwoLists(LinkedListt list1, LinkedListt list2) {
		Node head = new Node(0);
		Node p=head;
	 
		Node node1 = list1.head;
		Node node2 = list2.head;
	    while(node1!=null && node2!=null){
	        if(node1.data < node2.data){
	            p.next = node1;
	            node1 = node1.next;
	        }else{
	            p.next = node2;
	            node2 = node2.next;
	        }
	        p=p.next;
	    }
	 
	    if(node1!=null){
	        p.next = node1;
	    }
	 
	    if(node2!=null){
	        p.next = node2;
	    }
	 
	    return head.next;
	}

	public static void main(String[] args) {
		LinkedListt list1 = new LinkedListt();
		list1.addToFront(9);
		list1.addToFront(8);
		list1.addToFront(6);
		list1.addToFront(5);
		list1.addToFront(4);
		list1.addToFront(2);

		LinkedListt list2 = new LinkedListt();
		list2.addToFront(7);
		list2.addToFront(3);
		list2.addToFront(1);

		//list1.mergeList(list2);
		System.out.println("Merged List:");
		Node node = mergeTwoLists(list1,list2);
		while(node!=null){
			System.out.print(node.data+" ");
			node=node.next;
		}
		
	}

}
*/