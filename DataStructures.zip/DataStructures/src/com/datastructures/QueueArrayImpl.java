package com.datastructures;

class Queue {

	private int frontIndex = -1, lastIndex = -1, currentSize = 0, queueArr[];
	private int capacity;

	public Queue(int queueSize) {
		this.capacity = queueSize;
		this.queueArr = new int[this.capacity];
	}

	public void enqueue(int item) {
		if (isQueueFull()) {
			System.out.println("Queue is full");
		} else {
			lastIndex++;
			System.out.println("LastIndex:"+lastIndex);
			if (lastIndex == capacity - 1) {
				lastIndex = 0;
			}
			queueArr[lastIndex] = item;
			currentSize++;
			System.out.println("Element " + item+ " is pushed into the queue!!!");
		}
	}

	public void dequeue(int item) {
		if(isQueueEmpty())
			System.out.println("Queue is empty!!!");
		else{
			frontIndex++;
			if(frontIndex==capacity-1){
				frontIndex=0;
			}else
				currentSize--;
		}
	}
	
	public int getFront(){
		if(!isQueueEmpty())
			return queueArr[this.frontIndex];
		else
			return Integer.MIN_VALUE;
	}
	
	public int getRear(){
		if(!isQueueEmpty())
			return queueArr[lastIndex];
		else
			return Integer.MIN_VALUE;
	}
	
	public boolean isQueueFull() {
		boolean statusFlag = false;
		if (currentSize == capacity)
			statusFlag = true;
		return statusFlag;
	}
	
	public boolean isQueueEmpty() {
		boolean statusFlag = false;
		if (currentSize == 0)
			statusFlag = true;
		return statusFlag;
	}
	
	public int getQueueSize(){
		return currentSize;
	}
}

public class QueueArrayImpl{
	public static void main(String[] args) {
		Queue queue = new Queue(5);
		queue.enqueue(1);
		queue.enqueue(2);
		queue.enqueue(3);
		queue.enqueue(4);
		queue.enqueue(5);
		queue.enqueue(6);
		
		System.out.println("Size: "+queue.getQueueSize());
		//System.out.println(queue.getFront());
		//System.out.println(queue.getFront());
	}
}
