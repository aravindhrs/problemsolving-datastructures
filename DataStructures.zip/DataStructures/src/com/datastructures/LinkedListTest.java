package com.datastructures;

class Node {
	Node next;
	int data;

	public Node(int value) {
		data = value;
		next = null;
	}
}

class LinkedList {

	Node head;

	public void addFirst(int value) {
		Node newnode = new Node(value);
		newnode.next = head;
		head = newnode;
	}

	// Add or AddLast
	public void addLast(int value) {
		Node newnode = new Node(value);
		if (head == null) {
			head = newnode;
		} else {
			Node last = head;
			while (last.next != null) {
				last = last.next;
			}
			last.next = newnode;
		}
	}

	public void addAtIndex(Node previous, int value) {
		if (previous == null) {
			System.out.println("Previous node should not be null");
		} else {
			Node newnode = new Node(value);
			newnode.next = previous.next;
			previous.next = newnode;
		}
	}

	public void rotate(int kth) {
		if (kth == 0)
			return;

		int count = 1;

		Node last = head;
		while (count < kth && last != null) {
			last = last.next;
			count++;
		}

		if (last == null)
			return;

		Node kthNode = last;

		while (last.next != null) {
			last = last.next;
		}

		last.next = head;
		head = kthNode.next;
		kthNode.next = null;
	}

	public Node findModularNode(int k) {
		Node modularNode = null;
		if (k <= 0 || head == null)
			return modularNode;

		Node current = head;
		while (current != null) {
			if ((current.data % k) == 0)
				modularNode = current;

			current = current.next;
		}
		return modularNode;
	}

	// last occurrence
	public Node findModularNodeUsingFor(int k) {
		Node modularNode = null;
		if (k <= 0 || head == null)
			return modularNode;

		for (Node current = head; current != null; current = current.next) {
			if ((current.data % k) == 0)
				modularNode = current;
		}
		return modularNode;
	}

	public void deleteNode(int key) {
		if (head == null)
			return;

		Node currentNode = head, previousNode = null;
		if (currentNode != null && currentNode.data == key) {
			head = currentNode.next;
			return;
		}

		while (currentNode != null && currentNode.data != key) {
			previousNode = currentNode;
			currentNode = currentNode.next;
		}

		previousNode.next = currentNode.next;
	}

	public void deleteNodeByPosition(int position) {
		if (head == null)
			return;

		Node previousNode = head;

		if (position == 0) {
			head = previousNode.next;
			return;
		}

		for (int i = 0; previousNode != null && i < position - 1; i++) {
			previousNode = previousNode.next;
		}

		if (previousNode == null || previousNode.next == null)
			return;

		Node nextNode = previousNode.next.next;
		previousNode.next = nextNode;

	}

	public void deleteNodeByLastOccurence(int key) {
		if (head == null) {
			return;
		}
	}

	Node reverse(Node node) {
		Node prev = null;
		Node current = node;
		Node next = null;
		while (current != null) {
			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
		}
		node = prev;
		return node;
	}

	public int detectLoop() {
		Node slowPointer = head, fastPointer = head;
		while (slowPointer != null && fastPointer != null
				&& fastPointer.next != null) {
			slowPointer = slowPointer.next;
			fastPointer = fastPointer.next.next;
			if (slowPointer.data == fastPointer.data) {
				// removeLoop(slowPointer, fastPointer);
				return 1;
			}
		}
		return 0;
	}

	// Function to remove loop
	void removeLoop(Node loop, Node head) {
		Node ptr1 = loop;
		Node ptr2 = loop;

		int k = 1, i;
		while (ptr1.next != ptr2) {
			ptr1 = ptr1.next;
			k++;
		}

		ptr1 = head;
		ptr2 = head;
		for (i = 0; i < k; i++) {
			ptr2 = ptr2.next;
		}

		while (ptr2 != ptr1) {
			ptr1 = ptr1.next;
			ptr2 = ptr2.next;
		}

		ptr2 = ptr2.next;
		while (ptr2.next != ptr1) {
			ptr2 = ptr2.next;
		}

		ptr2.next = null;
	}

	// list.detectAndRemoveLoop(head);
	void detectAndRemoveLoop(Node node) {

		if (node == null || node.next == null)
			return;

		Node slow = node, fast = node;

		slow = slow.next;
		fast = fast.next.next;

		while (fast != null && fast.next != null) {
			if (slow == fast)
				break;

			slow = slow.next;
			fast = fast.next.next;
		}

		if (slow == fast) {
			slow = node;
			while (slow.next != fast.next) {
				slow = slow.next;
				fast = fast.next;
			}

			fast.next = null;
		}
	}

	public void printMiddle() {
		Node slowPointer = head, fastPointer = head;
		while (slowPointer != null && fastPointer != null
				&& fastPointer.next != null) {
			slowPointer = slowPointer.next;
			fastPointer = fastPointer.next.next;
		}
		System.out.println("Middle Element of linkedList:" + slowPointer.data);
	}

	public void printMiddleUsingOdd() {
		Node mid = head;
		if (mid == null)
			return;
		int counter = 0;
		while (head != null) {
			if (!(counter % 2 == 0)) {
				mid = mid.next;
			}
			counter++;
			head = head.next;
		}
		System.out.println("Middle Element of linkedList:" + mid.data);
	}

	public void print(String msg) {
		System.out.println(msg);

		Node current = head;

		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println();
	}

	public void deleteCompleteList() {
		head = null;
	}

	public void compare(Node node1, Node node2) {
		int value = 0;
		if (node1 == null && node2 == null)
			value = 1;

		while (node1 != null && node2 != null && node1.data == node2.data) {
			node1 = node1.next;
			node2 = node2.next;
		}

		if (node1 != null && node2 != null) {
			value = (node1.data > node2.data ? 1 : -1);
		}

		if (node1 != null && node2 == null) {
			value = 1;
		}

		if (node1 == null && node2 != null) {
			value = -1;
		}

		System.out.println("value:" + value);
	}

	public void nodeData_pairWiseSwapUsingIterative() {
		Node temp = head;
		while (temp != null && temp.next != null) {
			int tempData = temp.data;
			temp.data = temp.next.data;
			temp.next.data = tempData;
			temp = temp.next.next;
		}
	}

	public void moveToFront() {
		if (head == null || head.next == null)
			return;
		Node secondLast = null;
		Node last = head;

		while (last.next != null) {
			secondLast = last;
			last = last.next;
		}
		secondLast.next = null;
		last.next = head;
		head = last;
	}

	public void getNthNode(int pos) {
		Node current = head;
		int index = 0;
		while (current != null) {
			if (index == pos)
				System.out.println("The element in 'position:" + pos + "' is "
						+ current.data);
			index++;
			current = current.next;
		}
	}

	public boolean checkIdenticalList(LinkedList list2) {
		Node node1 = this.head, node2 = list2.head;
		if (this == list2)
			return true;

		while (node1 != null && node2 != null) {
			if (node1.data != node2.data)
				return false;
			node1 = node1.next;
			node2 = node2.next;
		}
		return (node1 == null && node2 == null);
	}
}

public class LinkedListTest {

	public static Node mergeTwoLists(LinkedList list1, LinkedList list2) {
		Node dummyHead = new Node(0);
		Node dummyNode = dummyHead;

		Node node1 = list1.head;
		Node node2 = list2.head;

		while (node1 != null && node2 != null) {
			if (node1.data < node2.data) {
				dummyNode.next = node1;
				node1 = node1.next;
			} else {
				dummyNode.next = node2;
				node2 = node2.next;
			}
			dummyNode = dummyNode.next;
		}

		if (node1 != null) {
			dummyNode.next = node1;
		}

		if (node2 != null) {
			dummyNode.next = node2;
		}

		return dummyHead.next;
	}

	public static void main(String[] args) {
		LinkedList linkedList = new LinkedList();
		/*
		 * linkedList.add(6); linkedList.add(4); linkedList.add(3);
		 * linkedList.addAtLast(5); linkedList.addAtLast(2);
		 * linkedList.addAfter(linkedList.head.next, 1); linkedList.print();
		 */

		linkedList.addFirst(7);
		linkedList.addFirst(3);
		linkedList.addFirst(1);

		// linkedList.print();
		/*
		 * System.out.println("---Rotate linkedlist from kth Node:");
		 * linkedList.rotate(2); linkedList.print(); Node modNode =
		 * linkedList.findModularNode(2); if (modNode != null)
		 * System.out.println("Modular Node: " + modNode.data); else
		 * System.out.println("null");
		 * 
		 * linkedList.deleteNode(1); linkedList.print();
		 * linkedList.deleteNodeByPosition(2); linkedList.print();
		 */

		LinkedList list1 = new LinkedList();
		list1.addFirst(9);
		list1.addFirst(8);
		list1.addFirst(6);
		list1.addFirst(5);
		list1.addFirst(4);
		// list1.add(2);

		System.out.println("Merged List:");
		Node node = mergeTwoLists(linkedList, list1);
		while (node != null) {
			System.out.print(node.data + " ");
			node = node.next;
		}

		System.out.println("");
		linkedList.printMiddleUsingOdd();
		System.out.println("------------");
		// linkedList.compare(linkedList.head,list1.head);
		list1.print("Before moveToFront");
		list1.moveToFront();
		list1.print("After moveToFront");
		System.out.println("------------");
		list1.print("Before swap Using Iterative");
		list1.nodeData_pairWiseSwapUsingIterative();
		list1.print("After swap Using Iterative");

		list1.getNthNode(5);

		System.out.println("------------");
		if (list1.checkIdenticalList(list1) == true)
			System.out.println("Both lists are identical");
		else
			System.out.println("Both lists are not identical");
		/*
		 * System.out.println("---------------------"); LinkedList list = new
		 * LinkedList(); list.head = new Node(1); list.head.next = new Node(2);
		 * list.head.next.next = new Node(3); list.head.next.next.next = new
		 * Node(4); list.head.next.next.next.next = new Node(5);
		 * list.head.next.next.next.next.next = new Node(6);
		 * list.head.next.next.next.next.next.next = new Node(7);
		 * list.head.next.next.next.next.next.next.next = new Node(8);
		 * 
		 * System.out.println("Original Linked list "); list.printList(head);
		 * Node res = list.reverseUtil(head, null); System.out.println("");
		 * System.out.println(""); System.out.println("Reversed linked list ");
		 * list.printList(res);
		 */
	}
}
