package com.datastructures;

public class QueueLinkedList {

}
