package com.datastructures;

class Stack {
	private int stackSize;
	private int top;
	private int[] stackArr;

	public Stack(int size) {
		this.stackSize = size;
		this.top = -1;
		this.stackArr = new int[stackSize];
	}

	public void push(int entry) {
		if (this.isStackFull()) {
			System.out.println("Stack is full ### Increasing the size!!!");
			incStackCapacity();
		} else
			this.stackArr[++top] = entry;
	}

	public void pop() {
		if (this.isStackEmpty())
			System.out.println("Stack is Empty!!!");
		else
			System.out.println("Removed entry:" + this.stackArr[top--]);
	}

	public void peekOrTop() {
		System.out.println("Peek Element:" + this.stackArr[top]);
	}

	public void incStackCapacity() {
		int[] newStackArr = new int[this.stackSize * 2];
		for (int i = 0; i < stackArr.length; i++) {
			newStackArr[i] = stackArr[i];
		}
		this.stackSize = this.stackSize * 2;
		this.stackArr = newStackArr;
		newStackArr=null;
	}

	public boolean isStackFull() {
		return (top == (stackSize - 1));
	}

	public boolean isStackEmpty() {
		return (top == -1);
	}
}

public class StackArrayImpl {

	public static String reverseWord(String word) {
		StringBuilder sb = new StringBuilder();
		int size = word.length();
		Stack stack = new Stack(size);
		for (int i = 0; i < size; i++) {
			stack.push(word.charAt(i));
		}
		while (!stack.isStackEmpty()) {
			// sb.append(stack.pop());
		}
		return sb.toString();
	}
	
	public static String convertDecialToBinary(int number){
        
        StringBuilder binary = new StringBuilder();
        Stack stack = new Stack(10);
        if(number == 0){
            binary.append("0");
        } else {
            while(number != 0){
                stack.push(number%2);
                number = number/2;
            }
        }
        while(!stack.isStackEmpty()){
            try {
                //binary.append(stack.pop());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return binary.toString();
    }

	public static void main(String[] args) {
		Stack stack = new Stack(10);
		stack.push(10);
		stack.push(34);
		stack.push(23);
		stack.push(54);
		stack.push(12);
		stack.push(76);
		stack.push(23);
		stack.push(32);
		stack.push(42);
		stack.push(76);
		stack.push(15);
		stack.push(16);
		stack.push(52);

		stack.peekOrTop();
		stack.pop();
		stack.peekOrTop();
		
		System.out.println(reverseWord("Hello"));
	}
}
