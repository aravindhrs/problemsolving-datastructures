package com.datastructures;

public class StackLinkedList {

	public static void main(String[] args) {
		
	}
}
