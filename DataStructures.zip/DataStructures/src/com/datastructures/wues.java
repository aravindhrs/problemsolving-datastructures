package com.datastructures;

public class wues {
	private String str =null;

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
	
	public int hashCode(){
		return str.hashCode();
	}
	
	public static void main(String[] args) {
		wues wues1 = new wues();
		System.out.println("Identity hashcode: "+System.identityHashCode(wues1.str));
		System.out.println(wues1.hashCode());
	}
}