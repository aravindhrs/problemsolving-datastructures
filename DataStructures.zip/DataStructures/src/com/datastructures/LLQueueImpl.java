package com.datastructures;

class QNode{
	
}

public class LLQueueImpl {

}
